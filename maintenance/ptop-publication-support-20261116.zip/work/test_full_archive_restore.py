import hashlib
import http.server
import importlib.util
import json
import threading
from functools import partial
from pathlib import Path

task_root = Path('E:/PtoP/work/restore-script-check')
task_root.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('archive_restore', 'E:/PtoP/work/github-upload/archive-tools/restore.py')
restore_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(restore_module)
fixture_root = task_root / 'archive'
fixture_root.mkdir()
web_root = task_root / 'assets'
web_root.mkdir()
small = b'local archive document\r\n'
parts = [b'first part\x00', b'\xffsecond part']
(fixture_root / 'document.txt').write_bytes(small)
for index, content in enumerate(parts):
    (web_root / f'part{index}').write_bytes(content)
handler = partial(http.server.SimpleHTTPRequestHandler, directory=str(web_root))
server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), handler)
thread = threading.Thread(target=server.serve_forever, daemon=True)
thread.start()
try:
    large = b''.join(parts)
    entries = [
        {'path': 'docs/document.txt', 'bytes': len(small), 'sha256': hashlib.sha256(small).hexdigest(), 'storage': {'kind': 'repository', 'path': 'document.txt'}},
        {'path': 'data/sample.bin', 'bytes': len(large), 'sha256': hashlib.sha256(large).hexdigest(), 'storage': {'kind': 'release', 'assets': [
            {'name': f'part{index}', 'url': f'http://127.0.0.1:{server.server_port}/part{index}', 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()} for index, content in enumerate(parts)
        ]}},
    ]
    restore_module.restore(fixture_root, task_root / 'restored', {'files': entries})
    for entry in entries:
        restore_module.check_file(task_root / 'restored' / entry['path'], entry)
    try:
        restore_module.child(task_root, '../outside')
    except ValueError:
        pass
    else:
        raise RuntimeError('Parent path traversal accepted')
    try:
        restore_module.restore(fixture_root, task_root / 'restored', {'files': entries})
    except FileExistsError:
        pass
    else:
        raise RuntimeError('Existing output directory accepted')
    broken = json.loads(json.dumps(entries))
    broken[1]['storage']['assets'][0]['sha256'] = '0' * 64
    try:
        restore_module.restore(fixture_root, task_root / 'bad-checksum', {'files': broken})
    except RuntimeError as error:
        if '分片完整性检查失败' not in str(error):
            raise
    else:
        raise RuntimeError('Corrupt checksum accepted')
    result = {'real_local_http_download': 'passed', 'split_reconstruction': 'passed', 'all_file_hashes': 'passed', 'checksum_mismatch_rejected': 'passed', 'existing_directory_rejected': 'passed', 'path_traversal_rejected': 'passed', 'scope': 'Synthetic fixtures through actual localhost HTTP; no GitHub download claim'}
    (task_root / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False))
finally:
    server.shutdown()
    server.server_close()
