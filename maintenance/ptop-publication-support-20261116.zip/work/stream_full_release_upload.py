import concurrent.futures
import hashlib
import json
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path('E:/PtoP')
REPOSITORY = 'Susurrium/jinyicapital-2026-e2e'
RELEASE_ID = 446939216
TAG = 'full-archive-2026-11-16'
GH = 'D:/GitHubCLI/gh.exe'
CHUNK_BYTES = 1024**3
STATE = ROOT / 'work/full-upload-stream-state.json'
LOCK = threading.Lock()
PROGRESS = {}


def github(endpoint):
    return json.loads(subprocess.check_output([GH, 'api', endpoint], encoding='utf-8'))


def remote_assets():
    return {asset['name']: asset for asset in github(f'repos/{REPOSITORY}/releases/{RELEASE_ID}/assets?per_page=100')}


def checked(asset, plan):
    if asset['state'] != 'uploaded' or asset['size'] != plan['bytes'] or asset.get('digest') != 'sha256:' + plan['sha256']:
        raise RuntimeError(f'Asset integrity mismatch: {plan["name"]}')
    return {'name': asset['name'], 'bytes': asset['size'], 'sha256': plan['sha256'], 'id': asset['id'], 'url': asset['browser_download_url']}


class SliceReader:
    def __init__(self, path, offset, size, name):
        self.stream = path.open('rb')
        self.stream.seek(offset)
        self.remaining = size
        self.name = name

    def read(self, size=-1):
        if not self.remaining:
            return b''
        value = self.stream.read(min(self.remaining, size if size > 0 else self.remaining))
        if not value:
            raise RuntimeError(f'Source file ended early: {self.name}')
        self.remaining -= len(value)
        with LOCK:
            PROGRESS[self.name] = PROGRESS.get(self.name, 0) + len(value)
        return value

    def close(self):
        self.stream.close()


def upload_one(plan, token):
    existing = remote_assets().get(plan['name'])
    if existing and existing['state'] == 'uploaded':
        result = checked(existing, plan)
        print(json.dumps({'event': 'verified_existing', 'name': plan['name']}), flush=True)
        return result
    if existing:
        raise RuntimeError(f'Asset upload already running; scheduled twice: {plan["name"]}')
    reader = SliceReader(ROOT / plan['path'], plan['offset'], plan['bytes'], plan['name'])
    url = f'https://uploads.github.com/repos/{REPOSITORY}/releases/{RELEASE_ID}/assets?' + urllib.parse.urlencode({'name': plan['name']})
    request = urllib.request.Request(url, data=reader, method='POST', headers={
        'Authorization': 'Bearer ' + token,
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        'User-Agent': 'PtoP-Archive-Uploader',
        'Content-Type': 'application/octet-stream',
        'Content-Length': str(plan['bytes']),
    })
    print(json.dumps({'event': 'stream_upload_started', 'name': plan['name'], 'bytes': plan['bytes']}), flush=True)
    try:
        with urllib.request.urlopen(request, timeout=180) as response:
            asset = json.load(response)
    except urllib.error.HTTPError as error:
        message = error.read().decode('utf-8', errors='replace')
        raise RuntimeError(f'GitHub upload HTTP {error.code} for {plan["name"]}: {message[:1000]}') from None
    finally:
        reader.close()
    result = checked(asset, plan)
    print(json.dumps({'event': 'stream_upload_verified', 'name': plan['name'], 'bytes': result['bytes']}), flush=True)
    return result


def build_plan():
    inventory = json.loads((ROOT / 'work/full-upload-inventory.json').read_text(encoding='utf-8'))
    files = []
    for entry in inventory['files']:
        if entry['bytes'] <= 50 * 1024**2:
            continue
        path = ROOT / entry['path']
        state = path.stat()
        if state.st_size != entry['bytes'] or state.st_mtime_ns != entry['mtime_ns']:
            raise RuntimeError(f'Source changed: {entry["path"]}')
        digest = hashlib.sha256()
        assets = []
        with path.open('rb') as stream:
            index = 0
            offset = 0
            while offset < entry['bytes']:
                index += 1
                size = min(CHUNK_BYTES, entry['bytes'] - offset)
                part_digest = hashlib.sha256()
                remaining = size
                while remaining:
                    block = stream.read(min(8 * 1024**2, remaining))
                    if not block:
                        raise RuntimeError(f'Source ended early: {path}')
                    digest.update(block)
                    part_digest.update(block)
                    remaining -= len(block)
                name = path.name if entry['bytes'] <= CHUNK_BYTES else f'{path.name}.part{index:03d}'
                assets.append({'path': entry['path'], 'name': name, 'offset': offset, 'bytes': size, 'sha256': part_digest.hexdigest()})
                offset += size
        files.append({'path': entry['path'], 'bytes': entry['bytes'], 'mtime_ns': entry['mtime_ns'], 'sha256': digest.hexdigest(), 'assets': assets})
        print(json.dumps({'event': 'source_hashed', 'path': entry['path'], 'parts': len(assets)}), flush=True)
    return files


def run():
    token = subprocess.check_output([GH, 'auth', 'token'], encoding='utf-8').strip()
    files = build_plan()
    planned = {asset['name']: asset for entry in files for asset in entry['assets']}
    results = {}
    inflight = {}
    started = time.monotonic()
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        while len(results) < len(planned):
            remote = remote_assets()
            for name, asset in remote.items():
                if name in planned and asset['state'] == 'uploaded':
                    results[name] = checked(asset, planned[name])
            for name, future in list(inflight.items()):
                if future.done():
                    results[name] = future.result()
                    del inflight[name]
            available = [asset for name, asset in planned.items() if name not in results and name not in inflight and name not in remote]
            available.sort(key=lambda item: item['bytes'])
            for asset in available[:max(0, 4 - len(inflight))]:
                inflight[asset['name']] = executor.submit(upload_one, asset, token)
            state = {
                'tag': TAG,
                'repository': REPOSITORY,
                'release_id': RELEASE_ID,
                'files': files,
                'verified_assets': results,
                'verified_asset_count': len(results),
                'expected_asset_count': len(planned),
                'verified_bytes': sum(asset['bytes'] for asset in results.values()),
            }
            STATE.write_text(json.dumps(state, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
            with LOCK:
                progress = {name: size for name, size in PROGRESS.items() if name not in results}
            print(json.dumps({'event': 'progress', 'elapsed_seconds': round(time.monotonic() - started), 'verified_assets': len(results), 'expected_assets': len(planned), 'verified_bytes': state['verified_bytes'], 'active_source_bytes_read': progress}), flush=True)
            if not inflight and len(results) < len(planned) and not any(name in remote and remote[name]['state'] == 'starter' for name in planned if name not in results):
                raise RuntimeError('Unfinished uploads with no active transfer')
            if len(results) < len(planned):
                time.sleep(20)
    final = []
    for entry in files:
        after = (ROOT / entry['path']).stat()
        if after.st_size != entry['bytes'] or after.st_mtime_ns != entry['mtime_ns']:
            raise RuntimeError(f'Source changed during upload: {entry["path"]}')
        final.append({**entry, 'assets': [results[asset['name']] for asset in entry['assets']]})
    destination = ROOT / 'work/full-upload-complete-assets.json'
    destination.write_text(json.dumps({'tag': TAG, 'repository': REPOSITORY, 'release_id': RELEASE_ID, 'files': final}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'event': 'all_uploads_verified', 'files': len(final), 'assets': len(results), 'bytes': sum(item['bytes'] for item in final)}), flush=True)


if __name__ == '__main__':
    run()
