import concurrent.futures
import importlib.util
import json
import subprocess
import time
from pathlib import Path

root = Path('E:/PtoP')
spec = importlib.util.spec_from_file_location('stream_upload', root / 'work/stream_full_release_upload.py')
upload = importlib.util.module_from_spec(spec)
spec.loader.exec_module(upload)
state = json.loads((root / 'work/full-upload-stream-state.json').read_text(encoding='utf-8'))
token = subprocess.check_output([upload.GH, 'auth', 'token'], encoding='utf-8').strip()
remote = upload.remote_assets()
plans = [asset for entry in state['files'] for asset in entry['assets'] if asset['name'] not in remote]


def ensure_asset(plan):
    while True:
        remote_asset = upload.remote_assets().get(plan['name'])
        if remote_asset is None:
            return upload.upload_one(plan, token)
        if remote_asset['state'] == 'uploaded':
            return upload.checked(remote_asset, plan)
        time.sleep(20)


with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
    futures = {executor.submit(ensure_asset, plan): plan for plan in plans}
    while futures:
        finished = [future for future in futures if future.done()]
        for future in finished:
            result = future.result()
            print(json.dumps({'event': 'extra_asset_verified', 'name': result['name'], 'bytes': result['bytes']}), flush=True)
            del futures[future]
        with upload.LOCK:
            active = dict(upload.PROGRESS)
        print(json.dumps({'event': 'extra_upload_progress', 'remaining_jobs': len(futures), 'source_bytes_read': active}), flush=True)
        if futures:
            time.sleep(20)
print(json.dumps({'event': 'extra_uploads_finished', 'assets': len(plans)}), flush=True)
