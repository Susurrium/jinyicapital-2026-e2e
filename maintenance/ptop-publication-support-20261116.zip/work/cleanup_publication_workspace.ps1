$ErrorActionPreference = 'Stop'
$taskRoot = 'E:\PtoP'
$taskReportRoot = Join-Path $taskRoot 'reports\publication-cleanup-20261116'
$taskState = Get-Content -LiteralPath (Join-Path $taskReportRoot 'preservation.json') -Raw | ConvertFrom-Json
$taskSupport = Join-Path $taskRoot $taskState.support_archive
if ((Get-FileHash -LiteralPath $taskSupport -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskState.support_archive_sha256) { throw '辅助资料 ZIP 指纹不一致' }
$taskLog = [Collections.Generic.List[object]]::new()
foreach ($taskRelative in @($taskState.cleanup_directories) + @($taskState.cleanup_work_files)) {
    $taskTarget = [IO.Path]::GetFullPath((Join-Path $taskRoot $taskRelative))
    if (-not $taskTarget.StartsWith('E:\PtoP\work\', [StringComparison]::OrdinalIgnoreCase)) { throw "清理路径超出 work：$taskTarget" }
    if ($taskTarget -in @('E:\PtoP\work', 'E:\PtoP\work\github-upload', 'E:\PtoP\work\repo-publication')) { throw "清理路径属于保留目录：$taskTarget" }
    if (-not (Test-Path -LiteralPath $taskTarget)) { continue }
    $taskItem = Get-Item -LiteralPath $taskTarget -Force
    if ($taskItem.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "禁止清理重解析点：$taskTarget" }
    $taskFiles = if ($taskItem.PSIsContainer) { @(Get-ChildItem -LiteralPath $taskTarget -File -Recurse -Force) } else { @($taskItem) }
    foreach ($taskFile in $taskFiles) {
        $taskFileRelative = [IO.Path]::GetRelativePath($taskRoot, $taskFile.FullName).Replace('\','/')
        $taskExpected = @($taskState.preserved_files | Where-Object path -eq $taskFileRelative)
        if ($taskExpected.Count -ne 1) { throw "文件未纳入保全 ZIP：$taskFileRelative" }
        if ((Get-FileHash -LiteralPath $taskFile.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskExpected[0].sha256) { throw "文件保全后发生变化：$taskFileRelative" }
    }
    $taskBytes = ($taskFiles | Measure-Object -Property Length -Sum).Sum
    if ($taskItem.PSIsContainer) {
        $taskNested = @(Get-ChildItem -LiteralPath $taskTarget -Directory -Recurse -Force)
        if (@($taskNested | Where-Object { $_.Name -eq '.git' -or ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) }).Count -gt 0) { throw "目录内存在 Git 元数据或重解析点：$taskTarget" }
        Remove-Item -LiteralPath $taskTarget -Recurse -Force
    } else { Remove-Item -LiteralPath $taskTarget -Force }
    $taskLog.Add([pscustomobject]@{ path=$taskRelative; files=$taskFiles.Count; bytes=$taskBytes })
}
$taskResult = [pscustomobject]@{ deleted=$taskLog; preserved_zip=$taskState.support_archive; source_and_data_retained=$true }
$taskResult | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $taskReportRoot 'cleanup.json') -Encoding utf8
$taskResult | ConvertTo-Json -Depth 8
