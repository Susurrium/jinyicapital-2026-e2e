import hashlib
import json
import re
import zipfile
from pathlib import Path

root = Path('E:/PtoP')
upload = root / 'work/github-upload'
inventory = json.loads((root / 'work/full-upload-inventory.json').read_text(encoding='utf-8'))
secrets = re.compile(r'-----BEGIN [A-Z ]*PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|AKIA[A-Z0-9]{16}|sk-proj-[A-Za-z0-9_-]{30,}')
results = []
for entry in inventory['files']:
    if entry['bytes'] > 50 * 1024**2:
        continue
    source = root / entry['path']
    destination = upload / 'local-archive' / entry['path']
    with source.open('rb') as stream:
        source_hash = hashlib.file_digest(stream, 'sha256').hexdigest()
    with destination.open('rb') as stream:
        destination_hash = hashlib.file_digest(stream, 'sha256').hexdigest()
    if source_hash != destination_hash or destination.stat().st_size != entry['bytes']:
        raise RuntimeError(f'Snapshot mismatch: {entry["path"]}')
    if destination.suffix.lower() in {'.py', '.md', '.ps1', '.json', '.toml', '.txt', '.xml', '.lock', '.yaml', '.yml'}:
        if secrets.search(destination.read_text(encoding='utf-8-sig')):
            raise RuntimeError(f'Credential marker requires review: {entry["path"]}')
    if destination.suffix.lower() in {'.zip', '.whl', '.docx'}:
        with zipfile.ZipFile(destination) as archive:
            if archive.testzip() is not None:
                raise RuntimeError(f'Archive CRC mismatch: {entry["path"]}')
    results.append({'path': entry['path'], 'bytes': entry['bytes'], 'sha256': source_hash, 'storage': {'kind': 'repository', 'path': 'local-archive/' + entry['path']}})
report = {'files': results, 'snapshot_files_identical_to_source': len(results), 'total_snapshot_bytes': sum(item['bytes'] for item in results)}
(root / 'work/full-upload-snapshot-verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in report.items() if key != 'files'}, ensure_ascii=False))
