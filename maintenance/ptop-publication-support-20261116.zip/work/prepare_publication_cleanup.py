import hashlib
import json
import zipfile
from pathlib import Path

root = Path('E:/PtoP')
report_root = root / 'reports/publication-cleanup-20261116'
report_root.mkdir(exist_ok=True)
support = root / 'deliverables/ptop-publication-support-20261116.zip'
targets = [
    'work/full-upload-staging', 'work/python-temp', 'work/restore-script-check',
    'work/upload-inspection', 'work/github-upload/my-part/work',
]
paths = [path for path in (root / 'work').iterdir() if path.is_file()]
paths += list((root / 'reports').glob('github*.json'))
for relative in targets:
    directory = root / relative
    if directory.exists():
        paths.extend(path for path in directory.rglob('*') if path.is_file())
entries = []
if support.exists():
    raise RuntimeError('Publication support archive already exists')
with zipfile.ZipFile(support, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(set(paths)):
        relative = path.relative_to(root).as_posix()
        data = path.read_bytes()
        archive.writestr(relative, data)
        entries.append({'path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(support) as archive:
    if archive.testzip() is not None:
        raise RuntimeError('Support archive ZIP CRC failed')
    for entry in entries:
        if hashlib.sha256(archive.read(entry['path'])).hexdigest() != entry['sha256']:
            raise RuntimeError(f'Archived file mismatch: {entry["path"]}')
state = {
    'support_archive': support.relative_to(root).as_posix(),
    'support_archive_sha256': hashlib.sha256(support.read_bytes()).hexdigest(),
    'preserved_files': entries,
    'cleanup_directories': targets,
    'cleanup_work_files': [path.relative_to(root).as_posix() for path in (root / 'work').iterdir() if path.is_file()],
}
(report_root / 'preservation.json').write_text(json.dumps(state, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'support_zip': str(support), 'files_preserved': len(entries), 'archive_bytes': support.stat().st_size, 'cleanup_directories': targets}, ensure_ascii=False, indent=2))
