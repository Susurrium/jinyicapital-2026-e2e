import argparse
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

ROOT = Path('E:/PtoP')
STAGING = ROOT / 'work/full-upload-staging'
REPOSITORY = 'Susurrium/jinyicapital-2026-e2e'
TAG = 'full-archive-2026-11-16'
GH = 'D:/GitHubCLI/gh.exe'
CHUNK_BYTES = 1024**3
STATE_PATH = ROOT / 'work/full-upload-assets.json'


def github(endpoint):
    value = subprocess.check_output([GH, 'api', endpoint], encoding='utf-8')
    return json.loads(value)


def release():
    values = github(f'repos/{REPOSITORY}/releases?per_page=100')
    matches = [value for value in values if value['tag_name'] == TAG]
    if len(matches) != 1:
        raise RuntimeError(f'Expected one release for {TAG}, got {len(matches)}')
    return matches[0]


def verify_asset(release_id, name, size, sha256):
    values = github(f'repos/{REPOSITORY}/releases/{release_id}/assets?per_page=100')
    matches = [value for value in values if value['name'] == name]
    if not matches:
        return None
    if len(matches) != 1:
        raise RuntimeError(f'Ambiguous release asset: {name}')
    asset = matches[0]
    if asset['state'] != 'uploaded' or asset['size'] != size or asset.get('digest') != 'sha256:' + sha256:
        raise RuntimeError(f'Remote asset checksum/state mismatch: {name}: {asset.get("digest")}')
    return {'name': name, 'bytes': size, 'sha256': sha256, 'id': asset['id'], 'url': asset['browser_download_url']}


def upload(path, release_id, sha256):
    size = path.stat().st_size
    existing = verify_asset(release_id, path.name, size, sha256)
    if existing:
        print(json.dumps({'event': 'already_verified', 'name': path.name, 'bytes': size}), flush=True)
        return existing
    print(json.dumps({'event': 'upload_started', 'name': path.name, 'bytes': size}), flush=True)
    started = time.monotonic()
    process = subprocess.Popen([GH, 'release', 'upload', TAG, str(path), '--repo', REPOSITORY], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding='utf-8')
    while process.poll() is None:
        time.sleep(10)
        if process.poll() is None:
            print(json.dumps({'event': 'upload_running', 'name': path.name, 'elapsed_seconds': round(time.monotonic() - started)}), flush=True)
    output = process.communicate()[0]
    if process.returncode:
        raise RuntimeError(f'Upload failed for {path.name}: {output}')
    result = verify_asset(release_id, path.name, size, sha256)
    if result is None:
        raise RuntimeError(f'Uploaded asset not found: {path.name}')
    print(json.dumps({'event': 'upload_verified', **result, 'elapsed_seconds': round(time.monotonic() - started)}), flush=True)
    return result


def save(state):
    STATE_PATH.write_text(json.dumps(state, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def remove_staged(path):
    resolved = path.resolve()
    if resolved.parent != STAGING.resolve() or not resolved.is_file():
        raise RuntimeError(f'Refusing to remove path outside staging: {resolved}')
    resolved.unlink()


def run():
    global STATE_PATH
    parser = argparse.ArgumentParser()
    parser.add_argument('--only')
    parser.add_argument('--state', type=Path)
    args = parser.parse_args()
    if args.state is not None:
        STATE_PATH = args.state
    STAGING.mkdir(exist_ok=True)
    inventory = json.loads((ROOT / 'work/full-upload-inventory.json').read_text(encoding='utf-8'))
    large = sorted((item for item in inventory['files'] if item['bytes'] > 50 * 1024**2), key=lambda item: item['bytes'])
    if args.only is not None:
        large = [item for item in large if item['path'] == args.only]
        if len(large) != 1:
            raise RuntimeError(f'Expected one selected file, got {len(large)}')
    current_release = release()
    state = json.loads(STATE_PATH.read_text(encoding='utf-8')) if STATE_PATH.exists() else {'tag': TAG, 'repository': REPOSITORY, 'release_id': current_release['id'], 'files': []}
    if state['release_id'] != current_release['id']:
        raise RuntimeError('Release ID changed')
    for entry in large:
        path = ROOT / entry['path']
        before = path.stat()
        if before.st_size != entry['bytes'] or before.st_mtime_ns != entry['mtime_ns']:
            raise RuntimeError(f'Source changed: {entry["path"]}')
        previous = next((item for item in state['files'] if item['path'] == entry['path']), None)
        if previous:
            for asset in previous['assets']:
                if not verify_asset(state['release_id'], asset['name'], asset['bytes'], asset['sha256']):
                    raise RuntimeError(f'Missing previous asset: {asset["name"]}')
            continue
        whole_hash = hashlib.sha256()
        assets = []
        if entry['bytes'] <= CHUNK_BYTES:
            with path.open('rb') as stream:
                while block := stream.read(8 * 1024**2):
                    whole_hash.update(block)
            assets.append(upload(path, state['release_id'], whole_hash.hexdigest()))
        else:
            total_parts = (entry['bytes'] + CHUNK_BYTES - 1) // CHUNK_BYTES
            with path.open('rb') as stream:
                for index in range(total_parts):
                    part = STAGING / f'{path.name}.part{index + 1:03d}'
                    part_hash = hashlib.sha256()
                    remaining = min(CHUNK_BYTES, entry['bytes'] - index * CHUNK_BYTES)
                    if part.exists():
                        remove_staged(part)
                    with part.open('xb') as destination:
                        while remaining:
                            block = stream.read(min(8 * 1024**2, remaining))
                            if not block:
                                raise RuntimeError(f'Unexpected source EOF: {path}')
                            destination.write(block)
                            part_hash.update(block)
                            whole_hash.update(block)
                            remaining -= len(block)
                    asset = upload(part, state['release_id'], part_hash.hexdigest())
                    assets.append(asset)
                    save({**state, 'current_file': entry['path'], 'verified_current_parts': assets})
                    remove_staged(part)
        after = path.stat()
        if before.st_size != after.st_size or before.st_mtime_ns != after.st_mtime_ns:
            raise RuntimeError(f'Source changed during upload: {entry["path"]}')
        state['files'].append({'path': entry['path'], 'bytes': entry['bytes'], 'sha256': whole_hash.hexdigest(), 'assets': assets})
        state.pop('current_file', None)
        state.pop('verified_current_parts', None)
        save(state)
        print(json.dumps({'event': 'source_file_completed', 'path': entry['path'], 'asset_count': len(assets), 'sha256': whole_hash.hexdigest()}), flush=True)
    print(json.dumps({'event': 'all_assets_uploaded', 'files': len(state['files']), 'assets': sum(len(item['assets']) for item in state['files']), 'bytes': sum(item['bytes'] for item in state['files'])}), flush=True)


if __name__ == '__main__':
    run()
