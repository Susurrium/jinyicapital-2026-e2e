$ErrorActionPreference = 'Stop'
$taskRoot = 'E:\PtoP'
$taskDestination = Join-Path $taskRoot 'work\github-upload\local-archive'
if (Test-Path -LiteralPath $taskDestination) { throw '原始资料快照目录已存在，拒绝覆盖' }
$taskInventory = Get-Content -LiteralPath (Join-Path $taskRoot 'work\full-upload-inventory.json') -Raw | ConvertFrom-Json
New-Item -ItemType Directory -Path $taskDestination | Out-Null
$taskCount = 0
foreach ($taskEntry in $taskInventory.files) {
    if ($taskEntry.bytes -gt 50MB) { continue }
    $taskSource = Join-Path $taskRoot $taskEntry.path
    $taskTarget = Join-Path $taskDestination $taskEntry.path
    if ((Get-Item -LiteralPath $taskSource).Length -ne $taskEntry.bytes) { throw "源文件大小变化：$($taskEntry.path)" }
    New-Item -ItemType Directory -Path (Split-Path -Parent $taskTarget) -Force | Out-Null
    Copy-Item -LiteralPath $taskSource -Destination $taskTarget
    $taskCount++
}
Write-Output "snapshot_files=$taskCount"
