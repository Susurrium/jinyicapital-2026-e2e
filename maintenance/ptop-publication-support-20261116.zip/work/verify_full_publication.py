import hashlib
import json
import subprocess
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('E:/PtoP')
UPLOAD = ROOT / 'work/github-upload'
REPOSITORY = 'Susurrium/jinyicapital-2026-e2e'
BRANCH = 'archive/full-project-2026-11-16'
TAG = 'full-archive-2026-11-16'
GH = 'D:/GitHubCLI/gh.exe'


def github(endpoint):
    return json.loads(subprocess.check_output([GH, 'api', endpoint], encoding='utf-8'))


head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=UPLOAD, encoding='utf-8').strip()
remote_ref = github(f'repos/{REPOSITORY}/git/ref/heads/{BRANCH}')
if remote_ref['object']['sha'] != head:
    raise RuntimeError('Published branch does not match local commit')
tree = github(f'repos/{REPOSITORY}/git/trees/{head}?recursive=1')
if tree['truncated']:
    raise RuntimeError('Remote tree is truncated')
remote_files = {entry['path']: entry['sha'] for entry in tree['tree'] if entry['type'] == 'blob'}
local_files = {}
for item in subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=UPLOAD).decode('utf-8').split('\0')[:-1]:
    metadata, filename = item.split('\t', 1)
    local_files[filename] = metadata.split()[1]
if remote_files != local_files:
    raise RuntimeError('Published file paths or Git blob hashes differ from local index')
release = github(f'repos/{REPOSITORY}/releases/tags/{TAG}')
if release['draft']:
    raise RuntimeError('Release is still a draft')
tag_ref = github(f'repos/{REPOSITORY}/git/ref/tags/{TAG}')
if tag_ref['object']['sha'] != head:
    raise RuntimeError('Release tag does not reference final commit')
manifest = json.loads((UPLOAD / 'FULL_ARCHIVE_MANIFEST.json').read_text(encoding='utf-8'))
planned = {asset['name']: asset for entry in manifest['files'] if entry['storage']['kind'] == 'release' for asset in entry['storage']['assets']}
for name in ('FULL_ARCHIVE_MANIFEST.json', 'SHA256SUMS.txt'):
    content = (UPLOAD / name).read_bytes()
    planned[name] = {'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}
assets = {asset['name']: asset for asset in release['assets']}
if set(assets) != set(planned):
    raise RuntimeError('Release assets differ from expected data and metadata files')
for name, expected in planned.items():
    actual = assets[name]
    if actual['state'] != 'uploaded' or actual['size'] != expected['bytes'] or actual.get('digest') != 'sha256:' + expected['sha256']:
        raise RuntimeError(f'Release checksum mismatch: {name}')
request = urllib.request.Request(assets['FULL_ARCHIVE_MANIFEST.json']['browser_download_url'], headers={'User-Agent': 'PtoP-Archive-Verifier'})
with urllib.request.urlopen(request, timeout=120) as response:
    downloaded = response.read()
if hashlib.sha256(downloaded).hexdigest() != planned['FULL_ARCHIVE_MANIFEST.json']['sha256']:
    raise RuntimeError('Public release manifest download differs from local file')
if subprocess.check_output(['git', 'status', '--porcelain'], cwd=UPLOAD):
    raise RuntimeError('Upload checkout has uncommitted changes')
source = ROOT / 'work/repo-publication'
if subprocess.check_output(['git', 'status', '--porcelain'], cwd=source):
    raise RuntimeError('Original integrated checkout has uncommitted changes')
source_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, encoding='utf-8').strip()
if source_head != '101ad3c8716c550d7c3ae6f4fb2e4282a246b5a0':
    raise RuntimeError('Original integrated archive commit changed')
result = {
    'verified_at_utc': datetime.now(timezone.utc).isoformat(),
    'repository': 'https://github.com/' + REPOSITORY,
    'branch': BRANCH,
    'commit': head,
    'repository_files': len(remote_files),
    'original_project_files': manifest['original_file_count'],
    'original_project_bytes': manifest['original_bytes'],
    'release_assets': len(assets),
    'data_assets': len(assets) - 2,
    'all_remote_git_blob_hashes_match_local': True,
    'all_remote_release_sha256_digests_match_local': True,
    'public_manifest_download_sha256_matches': True,
    'release_tag_matches_final_commit': True,
    'original_integrated_archive_unchanged': True,
    'release_url': release['html_url'],
    'snapshot_url': f'https://github.com/{REPOSITORY}/tree/{BRANCH}/local-archive',
    'restore_url': f'https://github.com/{REPOSITORY}/blob/{BRANCH}/archive-tools/README.md',
}
target = ROOT / 'reports/github-full-upload-20261116.json'
if target.exists():
    raise RuntimeError('Final upload receipt already exists; refusing overwrite')
target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
