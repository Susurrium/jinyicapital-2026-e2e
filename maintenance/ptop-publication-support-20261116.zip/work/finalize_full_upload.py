import hashlib
import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('E:/PtoP')
UPLOAD = ROOT / 'work/github-upload'
REPOSITORY = 'Susurrium/jinyicapital-2026-e2e'
TAG = 'full-archive-2026-11-16'
GH = 'D:/GitHubCLI/gh.exe'


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')


def run():
    inventory = json.loads((ROOT / 'work/full-upload-inventory.json').read_text(encoding='utf-8'))
    snapshot = json.loads((ROOT / 'work/full-upload-snapshot-verification.json').read_text(encoding='utf-8'))
    uploaded = json.loads((ROOT / 'work/full-upload-complete-assets.json').read_text(encoding='utf-8'))
    historical_source = json.loads((ROOT / 'reports/local-data/archive-audit.json').read_text(encoding='utf-8'))['source']
    bar1m = next(entry for entry in uploaded['files'] if entry['path'] == 'data/cpt_jyc_2026_e2e_bar1m.tar.gz')
    if bar1m['sha256'] != historical_source['sha256']:
        raise RuntimeError('Original 1-minute archive hash differs from historical audit')
    assets = json.loads(subprocess.check_output([GH, 'api', f'repos/{REPOSITORY}/releases/{uploaded["release_id"]}/assets?per_page=100'], encoding='utf-8'))
    remote = {asset['name']: asset for asset in assets}
    files = []
    for entry in snapshot['files']:
        path = UPLOAD / entry['storage']['path']
        with path.open('rb') as stream:
            if hashlib.file_digest(stream, 'sha256').hexdigest() != entry['sha256']:
                raise RuntimeError(f'Snapshot changed: {entry["path"]}')
        files.append(entry)
    all_assets = []
    for entry in uploaded['files']:
        planned_assets = []
        for asset in entry['assets']:
            current = remote[asset['name']]
            if current['state'] != 'uploaded' or current['size'] != asset['bytes'] or current.get('digest') != 'sha256:' + asset['sha256']:
                raise RuntimeError(f'Remote asset mismatch: {asset["name"]}')
            public = {**asset, 'url': f'https://github.com/{REPOSITORY}/releases/download/{TAG}/{asset["name"]}'}
            planned_assets.append(public)
            all_assets.append(public)
        if sum(asset['bytes'] for asset in planned_assets) != entry['bytes']:
            raise RuntimeError(f'Asset sizes do not reconstruct file: {entry["path"]}')
        state = (ROOT / entry['path']).stat()
        if state.st_size != entry['bytes'] or state.st_mtime_ns != entry['mtime_ns']:
            raise RuntimeError(f'Original large file changed: {entry["path"]}')
        files.append({'path': entry['path'], 'bytes': entry['bytes'], 'sha256': entry['sha256'], 'storage': {'kind': 'release', 'tag': TAG, 'assets': planned_assets}})
    if {item['path'] for item in files} != {item['path'] for item in inventory['files']}:
        raise RuntimeError('Some original project files have no publication mapping')
    if len(files) != len(inventory['files']):
        raise RuntimeError('Duplicate original project paths')
    manifest = {
        'version': 1,
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'repository': 'https://github.com/' + REPOSITORY,
        'release_tag': TAG,
        'scope': 'All inventoried project materials; local Python environment, Git metadata/history bundles and upload staging excluded',
        'authorization': 'Project owner confirmed organizer permission to upload after the competition ended',
        'original_file_count': len(files),
        'original_bytes': sum(item['bytes'] for item in files),
        'excluded': inventory['excluded'],
        'files': sorted(files, key=lambda item: item['path']),
    }
    write_json(UPLOAD / 'FULL_ARCHIVE_MANIFEST.json', manifest)
    checksum_text = ''.join(asset['sha256'] + '  ' + asset['name'] + '\n' for asset in sorted(all_assets, key=lambda item: item['name']))
    (UPLOAD / 'SHA256SUMS.txt').write_text(checksum_text, encoding='utf-8', newline='\n')
    test = json.loads((ROOT / 'work/restore-script-check/result.json').read_text(encoding='utf-8'))
    verification = {
        'verified_at_utc': datetime.now(timezone.utc).isoformat(),
        'original_files': len(files),
        'original_bytes': manifest['original_bytes'],
        'snapshot_files': len(snapshot['files']),
        'large_files': len(uploaded['files']),
        'release_assets': len(all_assets),
        'release_asset_bytes': sum(asset['bytes'] for asset in all_assets),
        'ordinary_file_hashes_match_original': True,
        'all_release_sizes_and_github_sha256_digests_match': True,
        'all_original_paths_have_storage_mapping': True,
        'original_large_file_sizes_and_modification_times_unchanged': True,
        'bar1m_sha256_matches_historical_audit': True,
        'restoration_script_checks': test,
        'scope': 'Archive file integrity and restoration; no additional financial-model or platform evaluation',
    }
    write_json(UPLOAD / 'FULL_UPLOAD_VERIFICATION.json', verification)
    entries = []
    for directory, directories, filenames in os.walk(UPLOAD):
        parent = Path(directory)
        for name in list(directories):
            candidate = parent / name
            relative = candidate.relative_to(UPLOAD).as_posix()
            if name in {'.git', '__pycache__'} or relative in {'work', 'my-part/work'}:
                directories.remove(name)
        for name in filenames:
            path = parent / name
            relative = path.relative_to(UPLOAD).as_posix()
            if relative == 'UPLOAD_MANIFEST.json':
                continue
            with path.open('rb') as stream:
                digest = hashlib.file_digest(stream, 'sha256').hexdigest()
            entries.append({'path': relative, 'bytes': path.stat().st_size, 'sha256': digest})
    write_json(UPLOAD / 'UPLOAD_MANIFEST.json', {'algorithm': 'SHA-256', 'self_excluded': 'UPLOAD_MANIFEST.json', 'file_count': len(entries), 'files': sorted(entries, key=lambda item: item['path'])})
    print(json.dumps(verification, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    run()
