import ast
import json
from pathlib import Path
from urllib.parse import unquote, urlsplit

import mistune

root = Path('E:/PtoP/work/github-upload')
markdown = mistune.create_markdown(renderer='ast')
issues = []
documents = 0


def links(tokens):
    for token in tokens:
        if token['type'] in {'link', 'image'}:
            yield token['attrs']['url']
        yield from links(token.get('children', []))


for path in root.rglob('*.md'):
    relative = path.relative_to(root)
    if '.git' in relative.parts or relative.parts[0] == 'local-archive' or 'work' in relative.parts:
        continue
    documents += 1
    for target in links(markdown(path.read_text(encoding='utf-8-sig'))):
        url = urlsplit(target)
        if url.scheme or url.netloc or not url.path:
            continue
        if not (path.parent / unquote(url.path)).exists():
            issues.append({'path': relative.as_posix(), 'target': target})
for path in (root / 'archive-tools').glob('*.py'):
    ast.parse(path.read_bytes(), filename=str(path))
result = {'current_document_count': documents, 'broken_relative_links': issues, 'restore_python_syntax': 'passed', 'historical_snapshot_documents': 'Preserved verbatim; original local paths and historical references retained'}
Path('E:/PtoP/work/full-upload-document-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
if issues:
    raise SystemExit(1)
